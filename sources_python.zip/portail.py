import time

from at_libs.atcmd import SerialModem, AT

DEVICE_PORT = "/dev/ttyUSB2"
DEVICE_PIN = "0000"

if __name__ == "__main__":
    with SerialModem(DEVICE_PORT, DEVICE_PIN) as modem:
        while True:
            (response, urc) = modem.send_command_get_answer(AT.write_cmd())
            assert response.endswith("OK")
            print(f"URC received since last:\n{urc}")
            print(f"Response:\n{response}")
            time.sleep(1)

